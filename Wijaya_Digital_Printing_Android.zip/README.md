# Wijaya Digital Printing — Android

Proyek Android WebView untuk menjalankan aplikasi laporan keuangan HTML secara lokal di satu perangkat. Tidak memerlukan server atau koneksi internet untuk penggunaan aplikasi.

## Membuat APK lewat GitHub Actions dari HP
1. Buat repositori GitHub kosong bernama `wijaya-digital-printing`.
2. Unggah seluruh isi folder ZIP ini ke akar repositori (bukan folder ZIP-nya).
3. Pastikan folder `.github/workflows` ikut terunggah.
4. Buka tab **Actions** di repositori.
5. Pilih workflow **Build Android APK**, tekan **Run workflow** bila belum berjalan otomatis.
6. Setelah selesai, buka hasil run dan unduh artifact **Wijaya-Digital-Printing-APK**.
7. Ekstrak ZIP artifact, lalu pasang `app-debug.apk` di Android.

## Catatan
- Data aplikasi disimpan lokal oleh WebView melalui localStorage pada perangkat.
- Gunakan fitur Backup Data secara berkala.
- APK ini belum diuji pada perangkat pengguna; lakukan uji coba dan pastikan backup tersedia sebelum memasukkan data penting.
