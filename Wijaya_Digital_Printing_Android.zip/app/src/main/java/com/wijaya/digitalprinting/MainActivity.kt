package com.wijaya.digitalprinting

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.webkit.JavascriptInterface
import android.content.Intent
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val CREATE_FILE = 4101
    private var pendingName = "backup-wijaya.json"
    private var pendingMime = "application/json"
    private var pendingBytes: ByteArray? = null
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val PICK_FILE = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
                return try { startActivityForResult(intent, PICK_FILE); true }
                catch (e: Exception) { filePathCallback = null; false }
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun saveFile(name: String, mime: String, base64: String) {
            runOnUiThread {
                try {
                    pendingName = name.ifBlank { "wijaya-export" }
                    pendingMime = mime.ifBlank { "application/octet-stream" }
                    pendingBytes = Base64.decode(base64, Base64.DEFAULT)
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = pendingMime
                        putExtra(Intent.EXTRA_TITLE, pendingName)
                    }
                    startActivityForResult(intent, CREATE_FILE)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Gagal menyiapkan file: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE) {
            val result = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
            return
        }
        if (requestCode == CREATE_FILE && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            try {
                val bytes = pendingBytes ?: return
                uri?.let { contentResolver.openOutputStream(it)?.use { out -> out.write(bytes) } }
                Toast.makeText(this, "File berhasil disimpan.", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal menyimpan: ${e.message}", Toast.LENGTH_LONG).show()
            } finally { pendingBytes = null }
        }
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
